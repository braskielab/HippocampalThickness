% At each point of a given hippocampal subregion, this script will
% calculate cortical thickness and average nonzero values to output mean
% cortical thickness for any given subregion.
% The method uses minimum line integrals, as described in:
% 
% I. Aganj, G. Sapiro, N. Parikshak, S. K. Madsen, and P. Thompson,
% "Measurement of cortical thickness from MRI by minimum line integrals on
% soft-classified tissue," Human Brain Mapping, vol. 30, no. 10,
% pp. 3188-3199, 2009. http://doi.org/10.1002/hbm.20740
%
% See also: MLI_thickness, makeLineSegments
%
% This code written by Deydeep Kothapalli.
% Original code by Iman Aganj.
% http://nmr.mgh.harvard.edu/~iman

%ARRAY OF SUBJECTS
%All subjects that have been hand-segmented
%SUBJECTS = {'1101816' '1101817' '1101814' '1101818' '1101793' '1101794' '1101829' '203421' '1101821' '1101819' '1101796' '1101797' '1101827' '1101828' '1101820' '1101822' '1101802' '1101813' '1101397' '1101896' '1101964' '1101943' '1101969' '1101486' '1102008' '1102024' '1102063' '1102019' '1102012' '1102042' '1101983' '203738' '1102059' '1102052' '1101991' '1102074' '1102075' '1102082' '1102086' '1102014' '1102073' '1102101' '1102144' '1102145' '1102139' '1102147' '1102107' '1102159' '1102166' '1102146' '203893' '1102157' '1102168' '1102165' '1102111' '1102153' '1102089' '1101611' '1102099' '1101679' '1102189' '1102187'};
SUBJECTS = {'1102157'	'1102168'	'1102165'	'1102111'	'1102153'	'1102089'	'1101611'	'1102099'	'1101679'	'1102189'	'1102187'};
%SUBJECTS = {'1101983' '1102145' '1101821' '203893' '1101827' '1101828' '1102059' '1102075' '1102045'};


for k=1:length(SUBJECTS)
    sub=SUBJECTS{k};
%% Read in the input images with nifti read
L_CA1_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_left_lfseg_corr_nogray_Braskie_QC_merged_CA1.nii.gz')
L_CA1=niftiread(L_CA1_str);

L_CA23DG_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_left_lfseg_corr_nogray_Braskie_QC_merged_CA23DG.nii.gz')
L_CA23DG=niftiread(L_CA23DG_str);

L_ERC_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_left_lfseg_corr_nogray_Braskie_QC_merged_ERC.nii.gz')
L_ERC=niftiread(L_ERC_str);

L_PHG_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_left_lfseg_corr_nogray_Braskie_QC_merged_PHG.nii.gz')
L_PHG=niftiread(L_PHG_str);

L_SUB_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_left_lfseg_corr_nogray_Braskie_QC_merged_SUB.nii.gz')
L_SUB=niftiread(L_SUB_str);

R_CA1_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_right_lfseg_corr_nogray_Braskie_QC_merged_CA1.nii.gz')
R_CA1=niftiread(R_CA1_str);

R_CA23DG_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_right_lfseg_corr_nogray_Braskie_QC_merged_CA23DG.nii.gz')
R_CA23DG=niftiread(R_CA23DG_str);

R_ERC_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_right_lfseg_corr_nogray_Braskie_QC_merged_ERC.nii.gz')
R_ERC=niftiread(R_ERC_str);

R_PHG_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_right_lfseg_corr_nogray_Braskie_QC_merged_PHG.nii.gz')
R_PHG=niftiread(R_PHG_str);

R_SUB_str=strcat('/Volumes/mbraskie/ADRC/HHR/',sub, '/Braskie_Atlas_Seg/final/cortical_thickness/',sub,'_right_lfseg_corr_nogray_Braskie_QC_merged_SUB.nii.gz')
R_SUB=niftiread(R_SUB_str);
%V=niftiread('/Volumes/mbraskie/ADRC/HHR/1101817/Braskie_Atlas_Seg/final/cortical_thickness/1101817_left_lfseg_corr_nogray_Braskie_QC_merged_CA1.nii.gz')

%% Create and save the line segments
% The radius parameter should be a few voxels larger than the expected
% maximum thickness. See the help of makeLineSegments.m for more parameters
% and parallelization options.
Lines = makeLineSegments(10);
save LineSegments Lines

%% Compute the thickness and the distance transform of the skeleton
% See the help of MLI_thickness.m for parameters and parallelization options.
% MLI_thickness_MEX.c must be compiled using: "mex MLI_thickness_MEX.c".
% Alternatively, the compiled files can be downloaded from:
% www.nitrc.org/projects/thickness
load LineSegments
%LEFT
[L_CA1_thickness, SkeletonDistance] = MLI_thickness(L_CA1, Lines);

L_CA23DG(L_CA23DG~=0) = 1
[L_CA23DG_thickness, SkeletonDistance] = MLI_thickness(L_CA23DG, Lines);

L_ERC(L_ERC~=0) = 1
[L_ERC_thickness, SkeletonDistance] = MLI_thickness(L_ERC, Lines);

L_PHG(L_PHG~=0) = 1
[L_PHG_thickness, SkeletonDistance] = MLI_thickness(L_PHG, Lines);

L_SUB(L_SUB~=0) = 1
[L_SUB_thickness, SkeletonDistance] = MLI_thickness(L_SUB, Lines);

%RIGHT
[R_CA1_thickness, SkeletonDistance] = MLI_thickness(R_CA1, Lines);

R_CA23DG(R_CA23DG~=0) = 1
[R_CA23DG_thickness, SkeletonDistance] = MLI_thickness(R_CA23DG, Lines);

R_ERC(R_ERC~=0) = 1
[R_ERC_thickness, SkeletonDistance] = MLI_thickness(R_ERC, Lines);

R_PHG(R_PHG~=0) = 1
[R_PHG_thickness, SkeletonDistance] = MLI_thickness(R_PHG, Lines);

R_SUB(R_SUB~=0) = 1
[R_SUB_thickness, SkeletonDistance] = MLI_thickness(R_SUB, Lines);

%Get a list of nonzero values, and average them
%LEFT
nonzero_thickness_L_CA1=nonzeros(L_CA1_thickness);
mean_nonzero_thickness_L_CA1=mean(nonzero_thickness_L_CA1);
nonzero_thickness_L_CA23DG=nonzeros(L_CA23DG_thickness);
mean_nonzero_thickness_L_CA23DG=mean(nonzero_thickness_L_CA23DG);
nonzero_thickness_L_ERC=nonzeros(L_ERC_thickness);
mean_nonzero_thickness_L_ERC=mean(nonzero_thickness_L_ERC);
nonzero_thickness_L_PHG=nonzeros(L_PHG_thickness);
mean_nonzero_thickness_L_PHG=mean(nonzero_thickness_L_PHG);
nonzero_thickness_L_SUB=nonzeros(L_SUB_thickness);
mean_nonzero_thickness_L_SUB=mean(nonzero_thickness_L_SUB);

%RIGHT
nonzero_thickness_R_CA1=nonzeros(R_CA1_thickness);
mean_nonzero_thickness_R_CA1=mean(nonzero_thickness_R_CA1);
nonzero_thickness_R_CA23DG=nonzeros(R_CA23DG_thickness);
mean_nonzero_thickness_R_CA23DG=mean(nonzero_thickness_R_CA23DG);
nonzero_thickness_R_ERC=nonzeros(R_ERC_thickness);
mean_nonzero_thickness_R_ERC=mean(nonzero_thickness_R_ERC);
nonzero_thickness_R_PHG=nonzeros(R_PHG_thickness);
mean_nonzero_thickness_R_PHG=mean(nonzero_thickness_R_PHG);
nonzero_thickness_R_SUB=nonzeros(R_SUB_thickness);
mean_nonzero_thickness_R_SUB=mean(nonzero_thickness_R_SUB);
%avg_thickness_data = {mean_nonzero_thickness_L_CA1,mean_nonzero_thickness_L_CA23DG,mean_nonzero_thickness_L_ERC,mean_nonzero_thickness_R_CA1,mean_nonzero_thickness_R_CA23DG,mean_nonzero_thickness_R_ERC};
avg_thickness_data = {mean_nonzero_thickness_L_CA1,mean_nonzero_thickness_L_CA23DG,mean_nonzero_thickness_L_ERC,mean_nonzero_thickness_L_PHG,mean_nonzero_thickness_L_SUB,mean_nonzero_thickness_R_CA1,mean_nonzero_thickness_R_CA23DG,mean_nonzero_thickness_R_ERC,mean_nonzero_thickness_R_PHG,mean_nonzero_thickness_R_SUB};
%avg_thickness_data = {mean_nonzero_thickness_L_CA1,mean_nonzero_thickness_L_CA23DG,mean_nonzero_thickness_L_PHG,mean_nonzero_thickness_L_SUB,mean_nonzero_thickness_R_CA1,mean_nonzero_thickness_R_CA23DG,mean_nonzero_thickness_R_PHG,mean_nonzero_thickness_R_SUB};
dlmwrite('/Volumes/mbraskie/ADRC/HHR/mean_cortical_thickness_values.csv',avg_thickness_data,'delimiter',',','-append');
end