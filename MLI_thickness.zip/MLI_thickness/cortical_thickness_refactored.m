% At each point of a given hippocampal subregion, this script will
% calculate cortical thickness and average nonzero values to output mean
% cortical thickness for any given subregion.
% The method uses minimum line integrals, as described in:
% 
% I. Aganj, G. Sapiro, N. Parikshak, S. K. Madsen, and P. Thompson,
% "Measurement of cortical thickness from MRI by minimum line integrals on
% soft-classified tissue," Human Brain Mapping, vol. 30, no. 10,
% pp. 3188-3199, 2009. http://doi.org/10.1002/hbm.20740
%
% See also: MLI_thickness, makeLineSegments
%
% This code written by Deydeep Kothapalli.
% Original code by Iman Aganj.
% http://nmr.mgh.harvard.edu/~iman

%ARRAY OF SUBJECTS
%All subjects that have been hand-segmented
%SUBJECTS = {'1101816' '1101817' '1101814' '1101818' '1101793' '1101794' '1101829' '203421' '1101821' '1101819' '1101796' '1101797' '1101827' '1101828' '1101820' '1101822' '1101802' '1101813' '1101397' '1101896' '1101964' '1101943' '1101969' '1101486' '1102008' '1102024' '1102063' '1102019' '1102012' '1102042' '1101983' '203738' '1102059' '1102052' '1101991' '1102074' '1102075' '1102082' '1102086' '1102014' '1102073' '1102101' '1102144' '1102145' '1102139' '1102147' '1102107' '1102159' '1102166' '1102146' '203893' '1102157' '1102168' '1102165' '1102111' '1102153' '1102089' '1101611' '1102099' '1101679' '1102189' '1102187'};
SUBJECTS = {'1101821' '1101828' '1101820' '1101822' '1101802' '1101813' '1101397' '1101896' '1101964' '1101943' '1101969' '1101486' '1102008' '1102024' '1102063' '1102019' '1102012' '1102042' '1101983' '203738' '1102059' '1102052' '1101991' '1102074' '1102075' '1102082' '1102086' '1102014' '1102073' '1102101' '1102144' '1102145' '1102139' '1102147' '1102107' '1102159' '1102166' '1102146' '203893' '1102157' '1102168' '1102165' '1102111' '1102153' '1102089' '1101611' '1102099' '1101679' '1102189' '1102187'};
SIDES = {'left','right'};
SUBREGIONS = {'CA1','CA23DG','SUB','PHG','ERC'};
HHR='/Volumes/mbraskie/ADRC/HHR/';
ATLAS='/Braskie_Atlas_Seg/';
FILE_SUFFIX='lfseg_corr_nogray_Braskie_QC_merged';

%%ADD HEADERS TO OUTPUT FILE
HEADERS={'SUBJECT','L_CA1_thickavg','L_CA23DG_thickavg','L_SUB_thickavg','L_PHG_thickavg','L_ERC_thickavg','R_CA1_thickavg','R_CA23DG_thickavg','R_SUB_thickavg','R_PHG_thickavg','R_ERC_thickavg'};
output_file=strcat(HHR,'mean_subfield_thickness_values.txt');
fid = fopen(output_file,'a');
fprintf(fid,'%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n',HEADERS{:});
fid = fclose(fid);

for k=1:length(SUBJECTS)
    subject=SUBJECTS{k};
    avg_thickness_data = {subject};
    for j=1:length(SIDES)
        side=SIDES{j};
        for s=1:length(SUBREGIONS)
            subregion=SUBREGIONS{s};
            %% Read in the input image with nifti read
            % Nonzero values are set to 1
            VOLUME=niftiread(strcat(HHR,subject,ATLAS,'final/subfield_thickness/',subject,'_', side,'_',FILE_SUFFIX,'_',subregion,'.nii.gz'));   
            VOLUME(VOLUME~=0) = 1;
            %% Create and save the line segments
            % The radius parameter should be a few voxels larger than the expected
            % maximum thickness. See the help of makeLineSegments.m for more parameters
            % and parallelization options.
            Lines = makeLineSegments(10);
            save LineSegments Lines

            %% Compute the thickness and the distance transform of the skeleton
            % See the help of MLI_thickness.m for parameters and parallelization options.
            load LineSegments
            try
                [Thickness, SkeletonDistance] = MLI_thickness(VOLUME, Lines);
            catch ME
                Thickness = 0;
            end

            %% Average nonzero thickness values point-wise them
            nonzero_thickness=nonzeros(Thickness);
            mean_nonzero_thickness=mean(nonzero_thickness);
     
            %% Append to the matrix  to the .txt
            %disp(side)
            %disp(subregion)
            %disp(mean_nonzero_thickness);
            avg_thickness_data = [avg_thickness_data,mean_nonzero_thickness];
        end 
    end
    avg_thickness_data = avg_thickness_data.';
    fid = fopen(output_file,'a');
    fprintf(fid,'%s,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n',avg_thickness_data{:});
    fid = fclose(fid);
end